package com.stephanleuch.partector_v6;

/**
 * Object to handle auxiliary packets received from Partector
 */
@SuppressWarnings("UnusedDeclaration")
public class AuxiliaryPacket {

    private float temperature;
    private float rh;
    private float ubatt;

    private static final int TEMPERATURE = 0;
    private static final int RH  = 1;
    private static final int UBATT = 2;

    public String data_type_temperature = "Temperature";
    public String data_type_rh = "rel. Humidity";
    public String data_type_ubatt = "Bat. Voltage";


    public String data_unit_temperature = "℃";
    public String data_unit_rh = "%";
    public String data_unit_ubatt = "V";

    AuxiliaryPacket(){
        // empty constructor
    }


    AuxiliaryPacket(String _temperature, String _rh, String _ubatt){
        temperature = Float.parseFloat(_temperature);
        rh = Float.parseFloat(_rh);
        ubatt = Float.parseFloat(_ubatt);
    }

    AuxiliaryPacket(float _temperature, float _rh, float _ubatt){
        temperature = _temperature;
        rh = _rh;
        ubatt = _ubatt;
    }


    public void setup(String data){
        String [] datastring;
        String value_temp;
        int valueCounter = 0;
        int lastTab = 1;

        data = data.substring(1);
        datastring = data.split("\t");


        for(int i = 0; i<3; i++) {
            set(i, Float.valueOf(datastring[i]));
        }

//        for(int index = 1;index < data.length();index++){ // index = 1 to ignore first position (packet type)
//            if(data.charAt(index) == '\t' || data.charAt(index) == 0){
//                value_temp = data.substring(lastTab,index);
//                set(valueCounter,value_temp);
//                lastTab = index;
//                valueCounter++;
//            }
//        }

    }

    public boolean set(int type, String value){
        switch (type){
            case TEMPERATURE:
                setTemperature(value);
                return true;
            case RH:
                setRH(value);
                return true;
            case UBATT:
                setUbatt(value);
                return true;
            default:
                System.out.println("");
                return false;
        }
    }


    public boolean set(int type, float value){
        switch (type){
            case TEMPERATURE:
                setTemperature(value);
                return true;
            case RH:
                setRH(value);
                return true;
            case UBATT:
                setUbatt(value);
                return true;
            default:
                return false;
        }
    }

    public void setTemperature(String value){ temperature = Float.parseFloat(value); }
    public void setRH(String value){ rh = Float.parseFloat(value); }
    public void setUbatt(String value){ ubatt = Float.parseFloat(value); }

    public void setTemperature(float value){ temperature = value; }
    public void setRH(float value){ rh = value; }
    public void setUbatt(float value){ ubatt = value; }

    public String getTemperatureAsString(){ return String.valueOf(temperature); }
    public String getRHAsString(){ return String.valueOf(rh); }
    public String getUbattAsString(){ return String.valueOf(ubatt); }

    public float getTemperature(){ return temperature; }
    public float getRH(){ return rh; }
    public float getUbatt(){ return ubatt; }
}
