package com.stephanleuch.partector_v6;

import android.widget.TextView;

// class used by LeDeviceListAdapter to display BLEDevices
class ViewHolder
{
    TextView deviceName;
    TextView deviceAddress;
}