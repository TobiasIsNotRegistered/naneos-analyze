package com.stephanleuch.partector_v6;

import android.os.AsyncTask;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.AbstractHttpEntity;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

class UploadTask extends AsyncTask<String, String, String>{

    final static String CIK = "4870873fba4ab9f2bcb60cc275b6e16a7c2b8866";
    private requestCallback mListener;
    ArrayList<Pair<String,String>> myData;

    public UploadTask(requestCallback listener){
        mListener = listener;
        myData = new ArrayList<>();
    }


    public UploadTask(requestCallback listener, ArrayList<Pair<String,String>> newData){
        mListener = listener;
        myData = newData;
    }

    @Override
    protected String doInBackground(String... uri) {
        mListener.startTask();

        if(!myData.isEmpty()){
            JSONObject result =  POST(myData);
            return result.toString();
        } else{
            return GET().toString();
        }

    }

    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);

        try {
            JSONObject response = new JSONObject(result);
            result = response.getString("status");
        } catch (JSONException e){
            e.printStackTrace();
        }

        if (result.matches("ok")) {
            System.out.println("Upload success!");
            mListener.successfulTask();
        } else {
            mListener.failedTask();
        }
        //Do anything with response..
    }

    public JSONObject POST(ArrayList<Pair<String,String>> data){
        InputStream inputStream;
        String result = "";
        HttpPost get = new HttpPost("http://m2.exosite.com/onep:v1/rpc/process");
        HttpClient httpclient = new DefaultHttpClient();

        String nameOfDataport = "ldsa";

        /**
         *  setup JSONObject arguments *
         */
        JSONArray arguments =  new JSONArray();
        JSONObject alias = getAlias(nameOfDataport);
        JSONArray dataStream = getData(data);
        arguments.put(alias);
        arguments.put(dataStream);
        arguments.put(new JSONObject());


        /**
         * setup JSONObject entity
         */
        JSONObject entity = new JSONObject();
        try {
            entity.put("calls",getCalls(32, arguments, "record"));
            entity.put("auth",getAuth(CIK));

        } catch (JSONException e){
            e.printStackTrace();
        }

        System.out.println(entity.toString());



        try {
            get.setHeader("Host", "m2.exosite.com:80");
            //get.setHeader("X-Exosite-CIK", CIK);
            get.setHeader("Accept", "application/x-www-form-urlencoded; charset=utf-8");

            //setting json object to post request.
            AbstractHttpEntity abstractHttpEntity = new ByteArrayEntity(entity.toString().getBytes("UTF8"));
            abstractHttpEntity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));

            get.setEntity(abstractHttpEntity);

            // Execute HTTP Post Request
            HttpResponse response = httpclient.execute(get);

            // receive response as inputStream
            inputStream = response.getEntity().getContent();

            // convert inputstream to string
            if(inputStream != null)
                result = convertInputStreamToString(inputStream);
            else
                result = "Did not work!";

        } catch (ClientProtocolException e) {
            System.out.println("ClientProtocolException");
        } catch (IOException e) {
            System.out.println("IOException");
        } finally {
            System.out.println(result);
        }

        try {
            JSONArray array = new JSONArray(result);
            return array.getJSONObject(0);
        }catch (JSONException e){
            System.out.println("couldn't convert String");
            return entity;
        }
    }

    private JSONArray getData(ArrayList<Pair<String,String>> _data) {
        JSONArray array = new JSONArray();
        for (int i = 0; i < _data.size();i++){
            JSONArray current = new JSONArray();
            current.put(Long.valueOf(_data.get(i).getFirst()));
            current.put(Float.valueOf(_data.get(i).getSecond()));
            array.put(current);
        }

        return array;
    }

    public JSONObject GET(){
        InputStream inputStream;
        String result = "";
        HttpPost get = new HttpPost("http://m2.exosite.com/onep:v1/rpc/process");
        HttpClient httpclient = new DefaultHttpClient();

        long unixTime = System.currentTimeMillis() / 1000L;
        int numberOfValues = 10;
        String nameOfDataport = "ldsa";


        /**
         *  setup JSONObject arguments *
         */
        JSONArray arguments =  new JSONArray();
        JSONObject alias = getAlias(nameOfDataport);
        JSONObject period = getPeriod(1, numberOfValues, unixTime);
        arguments.put(alias);
        arguments.put(period);


        /**
         * setup JSONObject entity
         */
        JSONObject entity = new JSONObject();
        try {
            entity.put("calls",getCalls(56, arguments, "read"));
            entity.put("auth",getAuth(CIK));

        } catch (JSONException e){
            e.printStackTrace();
        }

        System.out.println(entity.toString());

        try {
            get.setHeader("Host", "m2.exosite.com:80");
            get.setHeader("X-Exosite-CIK", CIK);
            get.setHeader("Accept", "application/x-www-form-urlencoded; charset=utf-8");

            //setting json object to post request.
            AbstractHttpEntity abstractHttpEntity = new ByteArrayEntity(entity.toString().getBytes("UTF8"));
            abstractHttpEntity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));

            get.setEntity(abstractHttpEntity);

            // Execute HTTP Post Request
            HttpResponse response = httpclient.execute(get);

            // receive response as inputStream
            inputStream = response.getEntity().getContent();

            // convert inputstream to string
            if(inputStream != null)
                result = convertInputStreamToString(inputStream);
            else
                result = "Did not work!";

        } catch (ClientProtocolException e) {
            System.out.println("ClientProtocolException");
        } catch (IOException e) {
            System.out.println("IOException");
        } finally {
            System.out.println(result);
        }

        try {
            return new JSONObject(result);
        }catch (JSONException e){
            return entity;
        }
    }

    JSONObject getAuth(String cik){
        JSONObject object = new JSONObject();
        try {
            object.put("cik", cik);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return object;
    }

    JSONObject getPeriod(long from, int numberOfValues, long until){
        JSONObject object = new JSONObject();
        try {
            object.put("endtime", until);
            object.put("limit", numberOfValues);
            object.put("selection", "all");
            object.put("sort", "desc");
            object.put("starttime", from);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return object;
    }

    JSONObject getAlias(String alias){
        JSONObject object = new JSONObject();
        try {
            object.put("alias", alias);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return object;
    }

    JSONArray getCalls(int id, JSONArray arguments, String procedure){
        JSONArray array = new JSONArray();
        JSONObject object = new JSONObject();
        try {
            object.put("id", String.valueOf(id));
            object.put("procedure", procedure);
            object.put("arguments", arguments);
            array.put(object);
        } catch (JSONException e){
            e.printStackTrace();
        }
        return array;
    }



    // convert inputstream to String
    private static String convertInputStreamToString(InputStream inputStream) throws IOException{
        BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream));
        String line;
        String result = "";
        while((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();
        return result;
    }

    public interface requestCallback{
        public void successfulTask();
        public void failedTask();
        public void startTask();
    }
}