package com.stephanleuch.partector_v6;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

// special FrameLayout which is always a square
public class SquareFrameLayout extends FrameLayout {

    public SquareFrameLayout(Context context){
        super(context);
    }

    public SquareFrameLayout(Context context, AttributeSet attributeSet){
        super(context, attributeSet);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec){
        //noinspection SuspiciousNameCombination
        super.onMeasure(widthMeasureSpec, widthMeasureSpec);
    }
}
