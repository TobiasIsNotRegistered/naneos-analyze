package com.stephanleuch.partector_v6;

/**
 * Object to handle standard packets received from Partector
 */
@SuppressWarnings("UnusedDeclaration")
public class StandardPacket {


    static final String data_type_time  = "Time";
    static final String data_type_ldsa  = "LDSA";
    static final String data_type_error = "Error";
    static final String data_unit_time  = "sec";
    static final String data_unit_ldsa  = "μm²/cm³";
    static final String data_unit_error = "no unit";

    static final int TIME  = 0;
    static final int LDSA  = 1;
    static final int ERROR = 2;
    static final int COLOR_GREEN  = 0;
    static final int COLOR_YELLOW = 1;
    static final int COLOR_RED    = 2;
    static final int ERROR_PULSE_LOW       = 0;
    static final int ERROR_PULSE_HIGH      = 1;
    static final int ERROR_RH_HIGH         = 2;
    static final int ERROR_OFFSET_HIGH     = 3;
    static final int ERROR_FLOW_LOW        = 4;
    static final int ERROR_BUFFER_OVERFLOW = 5;
    static final int ERROR_GENERIC         = 6;

    private int time;
    private float ldsa;
    private int error;

    public int ldsa_color = COLOR_GREEN;

    @SuppressWarnings("FieldCanBeLocal")
    private String coordinates = "0, 0";

    StandardPacket(){
        // empty constructor
    }

    StandardPacket(String _time, String _ldsa, String _error){
        setTime(Integer.valueOf(_time));
        setLDSA(Float.parseFloat(_ldsa));
        setError(Integer.valueOf(_error));
    }

    StandardPacket(float _time, float _ldsa, float _error){
        setTime(time);
        setLDSA(ldsa);
        setError(error);
    }


    public void setup(String data){

        /*String value_temp;
        int valueCounter = 0;
        int lastTab = 1;

        for(int index = 1;index < data.length();index++){ // index = 1 to ignore first position (packet type)
            if(data.charAt(index) == '\t'){
                value_temp = data.substring(lastTab,index);
                set(valueCounter,value_temp);
                lastTab = index;
                valueCounter++;
            } else if(index == data.length()-1){
                value_temp = data.substring(lastTab+1,index+1);
                set(valueCounter,value_temp);
                lastTab = index;
                valueCounter++;

            }
        }*/
        setLDSA(data);
        error = 0;

    }

    public boolean set(int type, String value){
        switch (type){
            case TIME:
                setTime(value);
                return true;
            case LDSA:
                setLDSA(value);
                return true;
            case ERROR:
                setError(value);
                return true;
            default:
                System.out.println("");
                return false;
        }
    }

    public boolean set(int type, float value){
        switch (type){
            case TIME:
                setTime((int)value);
                return true;
            case LDSA:
                setLDSA(value);
                return true;
            case ERROR:
                setError((int)value);
                return true;
            default:
                return false;
        }
    }

    public void setTime(String value){
        time = Integer.valueOf(value);
    }
    public void setLDSA(String value){
        ldsa = Float.parseFloat(value);
        if(ldsa < 50){
            ldsa_color = COLOR_GREEN;
        } else if(ldsa < 250){
            ldsa_color = COLOR_YELLOW;
        } else{
            ldsa_color = COLOR_RED;
        }
    }
    public void setError(String value){
        error = Integer.valueOf(value);
    }


    public void setTime(int value){
        time = value;
    }
    public void setLDSA(float value){
        ldsa = value;
        if(ldsa < 50){
            ldsa_color = COLOR_GREEN;
        } else if(ldsa < 250){
            ldsa_color = COLOR_YELLOW;
        } else{
            ldsa_color = COLOR_RED;
        }
    }
    public void setError(int value){
        error = value;
    }
    public void setCoordinates(String value){
        coordinates = value;
    }

    public String getTimeAsString(){
        return String.valueOf(time);
    }

    public String getLDSAAsString(){
        return String.valueOf(ldsa);
    }

    public String getErrorAsString(){
        return String.valueOf(error);
    }

    public int getTime(){
        return time;
    }

    public float getLDSA(){
        return ldsa;
    }
    public int getError(){
        return error;
    }
    public String getCoordinates(){
        return coordinates;
    }
}
