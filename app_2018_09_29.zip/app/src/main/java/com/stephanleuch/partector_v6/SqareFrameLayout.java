package com.stephanleuch.partector_v6;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;


public class SqareFrameLayout extends FrameLayout {

    public SqareFrameLayout(Context context){
        super(context);
    }

    public SqareFrameLayout(Context context, AttributeSet attributeSet){
        super(context, attributeSet);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec){
        super.onMeasure(widthMeasureSpec, widthMeasureSpec);
    }
}
