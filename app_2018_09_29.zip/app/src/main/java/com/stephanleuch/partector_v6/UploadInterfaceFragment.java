package com.stephanleuch.partector_v6;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Switch;

public class UploadInterfaceFragment extends Fragment {


    public static final int STATE_INACTIVE       = 0;
    public static final int STATE_ACTIVE         = 1;
    public static final int STATE_ACTIVE_PROCESS = 2;
    public static final int STATE_ACTIVE_SUCCESS = 3;
    public static final int STATE_ACTIVE_FAILED  = 4;

    public View view;

    public Switch uploadSwitch;
    public ImageView cloudImg;
    public ImageView successImg;
    public ImageView failedImg;
    public ProgressBar progressBar;

    public OnUploadInterfaceFragmentInteractionListener mListener;

    public UploadInterfaceFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_upload_interface, container, false);

        progressBar = (ProgressBar) view.findViewById(R.id.upload_progress);
        successImg = (ImageView) view.findViewById(R.id.success_image);
        failedImg = (ImageView) view.findViewById(R.id.failed_image);
        cloudImg = (ImageView) view.findViewById(R.id.cloud_image);
        cloudImg.setOnClickListener(new ImageView.OnClickListener(){
            @Override
            public void onClick(View view){
                if (uploadSwitch.getVisibility() == View.INVISIBLE){
                    uploadSwitch.setVisibility(View.VISIBLE);
                    mListener.changeLayoutMargin(0);
                } else {
                    uploadSwitch.setVisibility(View.INVISIBLE);
                    mListener.changeLayoutMargin(-45);
                }
            }
        });

        uploadSwitch = (Switch) view.findViewById(R.id.upload_switch);
        uploadSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                mListener.setUploadData(isChecked);
                if (isChecked){
                    changeState(STATE_ACTIVE);
                } else {
                    changeState(STATE_INACTIVE);
                }
            }
        });

        return view;

    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        try {
            mListener = (OnUploadInterfaceFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnUploadInterfaceFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public void changeState(int newState){
        switch (newState){
            case STATE_INACTIVE:
                cloudImg.setImageResource(R.drawable.cloud_ic_grey);
                progressBar.setVisibility(View.INVISIBLE);
                successImg.setVisibility(View.INVISIBLE);
                failedImg.setVisibility(View.INVISIBLE);
                return;
            case STATE_ACTIVE:
                cloudImg.setImageResource(R.drawable.cloud_ic);
                mListener.uploadData();
                return;
            case STATE_ACTIVE_PROCESS:
                progressBar.setVisibility(View.VISIBLE);
                successImg.setVisibility(View.INVISIBLE);
                failedImg.setVisibility(View.INVISIBLE);
                return;
            case STATE_ACTIVE_SUCCESS:
                progressBar.setVisibility(View.INVISIBLE);
                successImg.setVisibility(View.VISIBLE);
                failedImg.setVisibility(View.INVISIBLE);
                return;
            case STATE_ACTIVE_FAILED:
                progressBar.setVisibility(View.INVISIBLE);
                successImg.setVisibility(View.INVISIBLE);
                failedImg.setVisibility(View.VISIBLE);
                return;
            default:
        }

    }

    public interface OnUploadInterfaceFragmentInteractionListener {
        public void changeLayoutMargin(int newMarginTop);
        public void setUploadData(boolean state);
        public void uploadData();
    }

}
