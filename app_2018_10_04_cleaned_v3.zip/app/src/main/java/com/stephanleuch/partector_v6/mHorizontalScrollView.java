package com.stephanleuch.partector_v6;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.HorizontalScrollView;

// special ScrollView which allows zooming (used to display bar graph data I suppose)
public class mHorizontalScrollView extends HorizontalScrollView {

    public int position = 0;
    private boolean first = false;
    private boolean second = false;
    private float last_position_first;
    private float last_position_second;

    private OnZoomListener zoomListener;

    public void setOnZoomListener(OnZoomListener listener){
        zoomListener = listener;
    }


    public mHorizontalScrollView(Context context){
        super(context);
    }

    public mHorizontalScrollView(Context context, AttributeSet attributeSet){
        super(context, attributeSet);
    }

    @Override
    protected void onScrollChanged(int l, int t, int oldl, int oldt) {

        position = l;

        //Log.i("Scrolling", "X from [" + oldl + "] to [" + l + "] width is " + getWidth());
        super.onScrollChanged(l, t, oldl, oldt);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event){
        float zoom;
        float zoom_first;
        float zoom_second;

        switch (event.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
                last_position_first = event.getX(0);
                first = true;
                break;
            case MotionEvent.ACTION_UP:
                first = false;
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                last_position_second = event.getX(1);
                second = true;
                break;
            case MotionEvent.ACTION_POINTER_UP:
                second = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if (first && second) {
                    try {
                        zoom_first = last_position_first - event.getX(0);
                        last_position_first = event.getX(0);
                        zoom_second = event.getX(1) - last_position_second;
                        last_position_second = event.getX(1);

                        zoom = zoom_first + zoom_second;

                        if (event.getX(0) < event.getX(1)) {
                            System.out.println("zoom: " + String.valueOf(zoom));
                            zoomListener.zoomBars(zoom);

                        } else {
                            System.out.println("zoom: " + String.valueOf(-zoom));
                        }
                    } catch (Exception e) {
                        return super.onTouchEvent(event);
                    }


                }
                break;
        }
        return super.onTouchEvent(event);
    }

    public interface OnZoomListener{
        void zoomBars(float z);

    }
}
