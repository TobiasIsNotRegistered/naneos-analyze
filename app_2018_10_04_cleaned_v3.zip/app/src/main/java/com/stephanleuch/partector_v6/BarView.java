package com.stephanleuch.partector_v6;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

// used to display data as BarDiagram
@SuppressWarnings("UnusedDeclaration")
public class BarView extends TextView {
    public static int COLOR_GREEN   = 0;
    public static int COLOR_YELLOW  = 1;
    public static int COLOR_RED     = 2;
    public static int COLOR_NEUTRAL = 3;

    int index;
    public float value = 0;

    public float timeStamp;

    public int valueColor = COLOR_GREEN;
    public int activeColor = COLOR_NEUTRAL;

    public BarView(Context context){
        super(context);
    }

    public BarView(Context context, AttributeSet attributeSet){
        super(context, attributeSet);
    }

    /*@Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec){
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }*/
}
